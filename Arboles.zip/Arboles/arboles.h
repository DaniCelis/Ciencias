#ifndef ARBOLES_H
#define ARBOLES_H

using namespace std;

struct nodo{
	int valor;
	int izq,der;
};

class Arbol{
	nodo *arbol;
	int tam;
	public:
		Arbol(int max=10){
			tam=max;
			arbol=new nodo[max];
			arbol->valor=0;
			arbol->izq=0;
			arbol->der=1;
		}
        void insertar(int v);
        void buscar(int v);
        void eliminar(int v);
        void imprimir();
};


void Arbol::insertar(int v){
	nodo *aux,*aux1=arbol;
	aux= new nodo;
	int j=1;
	if(aux1->der!=0){
		if(aux1->izq==0){
			aux1->izq=aux1->der; //Si no tiene a nadie aqui insertara la Raiz y aumenta el valor de der para saber cual esta disponible
			if(aux1->der<tam){
				aux1->der=aux1->der+1;
			}
			// este 	aux1[aux1->izq].valor es lo mismo que aux1->valor pero en la posicion en la que esta del arreglo
            aux1[aux1->izq].valor=v;  //Agrega a la posion que tiene en izquiera el valor de V
			aux1[aux1->izq].izq=0;  // estos 3 agregan los datos en la posicion libre que seria la raiz en este if
			aux1[aux1->izq].der=0;
		}else{
			aux->valor=v;
			aux->izq=0;      // guardamos el nodo para luego insertarlo en la posicion libre
			aux->der=0;
			while(j!=tam){   // ciclo hasta que encuentre donde debe insertarce
				if(aux->valor > aux1[j].valor){   // Si el que ingresa es mayor al que esta en la posicion
					if(aux1[j].der==0){    // Si der esta en 0 le pone la pos para saber que ya esta
                        aux1[aux1[0].der].valor=aux->valor;
						aux1[aux1[0].der].izq=aux->izq;
						if(aux1[0].der==tam){
                            aux1[aux1[0].der].der=aux->der;   // Si llega hasta el tama�o der del posicion 0 valdra 0 indicando que ya no hay mas espacios
                            aux1[0].der=0;
						}else{
							aux1[j].der=aux1[0].der;
							if(aux1[0].der<tam){
								aux1[0].der=aux1[0].der+1;     // Si no simplemente busca la otra pos libre
							}
						}
						//aux1[j].der=aux1[0].der;
						break;
						}
     				j=aux1[j].der; // para que vuelva a arrancar el ciclo desde la derecha del que pregunto si ya tiene uno mayor a la derecha
					}else{
					if(aux1[j].izq==0){         // Si no tiene menor agregara el nuevo
                        aux1[aux1[0].der].valor=aux->valor;
						aux1[aux1[0].der].der=aux->der;
						if(aux1[0].der==tam){
                            aux1[aux1[0].der].izq=aux->izq;
                            aux1[0].der=0;
						}else{
                            aux1[j].izq=aux1[0].der;
                            if(aux1[0].der<tam){
								aux1[0].der=aux1[j].izq+1;   // buscara la otra pos para insertar
							}
						}
						break;
					}
     				j=aux1[j].izq; // llamara desde la izquierda si ya yiene a uno
				}
			}
		//	cout<<"salio"<<endl;
		}
	}else{ // Si der de la posicion 0 es 0 dira que no hay espacio
			cout<<"No hay espacio";
	}
}
void Arbol::imprimir(){  // imprimir lo que lleva del arbol puedes cambiarle el numero del for para que no quede feo
	for(int i=0;i<=10;i++){
		cout<<"Pos :"<<i<<endl;
		cout<<"Valor: "<<arbol[i].valor<<endl;
		cout<<"Izq: "<<arbol[i].izq<<endl;
		cout<<"Der: "<<arbol[i].der<<endl<<endl;
	}
}
void Arbol::buscar(int v){
    nodo *aux,*aux1=arbol;
	aux= new nodo;
	int j=1;
	aux->valor=v;
	while(j!=tam){ // ciclo hasta acabar la busqueda
		if(aux->valor==aux1[j].valor){ // lo encontro
			cout<<"Se encontro"<<endl;
			break;
		}
		if(aux->valor > aux1[j].valor){
			if(aux1[j].der!=0){
				j=aux1[j].der;   // como es mayor y tiene a alguien en derecha empezara el ciclo desde el de derecha
			}else{
				cout<<"No se encuentra en el arbol"<<endl; // si no esta
				break;
			}
		}
        if(aux->valor < aux1[j].valor){
			if(aux1[j].izq!=0){
				j=aux1[j].izq; // como es menor y tiene a alguien en izquiera empezara de nuevo el ciclo
			}else{
				cout<<"No se encuentra en el arbol"<<endl;
				break;
			}
		}

	}
}
void Arbol::eliminar(int v){
    nodo *aux,*aux1=arbol;
	aux= new nodo;
	int j=1,padre,cont=0;
	aux->valor=v;
	while(j!=tam){  // ciclo hasta buscar el de eliminar si es que lo encuentra
		if(aux->valor==aux1[j].valor){   // cuando lo encuentra los cont es para saber cuantos hijos tiene
   			if(aux1[j].der!=0){
				cont++;
			}
			if(aux1[j].izq!=0){
				cont++;
			}
			if(cont==0){            // desconectar al padre del hijo
    			if(aux->valor>aux1[padre].valor){
     				aux1[padre].der=0;
    			}else{
					aux1[padre].izq=0;
    			}
    			aux1[0].der=j;
			}
			break;
		}
		if(aux->valor > aux1[j].valor){
			if(aux1[j].der!=0){
				padre=j;
				j=aux1[j].der;
			}else{
				cout<<"No se encuentra en el arbol"<<endl;
				break;
			}
		}
        if(aux->valor < aux1[j].valor){
			if(aux1[j].izq!=0){
				padre=j;
				j=aux1[j].izq;
			}else{
				cout<<"No se encuentra en el arbol"<<endl;
				break;
			}
		}

	}
}
#endif
