#include <cstdlib>
#include <iostream>
#include<conio.h>
#include "arboles.h"

using namespace std;

int main(int argc, char *argv[]){
	Arbol arbol(40);
//	cout<<"asd"<<endl;
	arbol.insertar(100);
	arbol.insertar(50);
	arbol.insertar(150);
	arbol.insertar(30);
	arbol.insertar(75);
    arbol.insertar(125);
	arbol.insertar(170);
	arbol.insertar(90);
	arbol.insertar(10);
	arbol.insertar(130);
	arbol.imprimir();
	arbol.eliminar(130);
	arbol.insertar(2);
	arbol.imprimir();
	arbol.buscar(2);
	getch();
}
