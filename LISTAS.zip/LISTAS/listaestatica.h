#ifndef LISTAESTATICA_H
#define LISTAESTATICA_H
using namespace std;
template <class T>
class lista{
	int tam, posAct;
	T *arr;

	public:
		lista(int tamano = 20){
			arr = new T[tamano];
			tam = tamano;
			posAct = 0;
		}
		
		~lista(){
			delete arr;
		}
		
	//	template <class T>
		void insertar(T dato){
			if(lista_llena()){
				cout<<"Lista llena"<<endl;
			}else{
				arr[posAct] = dato;
				posAct++;	
			}
		
		}
		
	//	template <class T>
		T borrar_pos(int pos){
			T aux;
			aux= arr[pos];
			for(int i=pos; pos<posAct; pos++){
				arr[pos]=arr[pos+1];			
			}
			posAct--;
			
			return aux;
		}
		
		bool lista_vacia(){
			if(posAct == 0){
				return true;
			}else{
				return false;
			}
		}
		
		bool lista_llena(){
			if(posAct>tam){
				return true;
			}else{
				return false;
			}
		}
		
		
	//	template <class T>
		T retornar(int pos){
			return arr[pos];
		}
	
};








#endif





