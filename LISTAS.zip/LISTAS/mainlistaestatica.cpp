#include <iostream>
#include "listaestatica.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
int main(int argc, char** argv) {
	
	lista<int> L(5);
	L.insertar(10);
	L.insertar(20);
	L.borrar_pos(1);
	L.insertar(15);
	L.insertar(20);
	L.borrar_pos(2);
	L.insertar(18);
	L.insertar(20);
	cout<<L.retornar(0)<<endl;
	while(!L.lista_vacia()){
		cout<<L.retornar(0)<<" ";
		L.borrar_pos(0);
	}
	
}
