#ifndef LISTADOBLE_H
#define LISTADOBLE_H

template<class T>
struct nodo{
	T info;
	nodo<T> *ant,*sig;
};
template<class T>
class listaDoble{
	nodo<T> *cab,*z;
	int tam;
	public:
		listaDoble(T infonula){
			tam=0;
			cab=new nodo<T>;
			z=new nodo<T>;
			cab->ant=z->sig=NULL;
			cab->sig=z;
			z->ant=cab;	
			cab->info=z->info=infonula;
		}
		void insertar_pos(T dato,int pos);
		T eliminar_pos(int pos);
		bool lista_vacia();
		T revisar_pos(int pos);
		//revisar anterior(pos) y revisar Siguiente para 
};
template<class T>
void listaDoble<T>::insertar_pos(T dato,int pos){
	int i;
	nodo<T> *aux,*aux1=cab;
	aux= new nodo<T>;
	aux->info=dato;
	for(i=1;i<pos&& aux1->sig!=NULL;i++){
		aux1=aux1->sig;
	}
	aux->sig=aux1->sig;
	aux1->sig->ant=aux;
	aux1->sig=aux;
	aux->ant=aux1;	
	tam++;
}
template<class T>
T listaDoble<T>::eliminar_pos(int pos){
	int i;
	nodo<T> *aux,*aux1=cab;
	aux=new nodo<T>;
	for(i=1;i<=pos&& aux1->sig!=NULL;i++){
		aux1=aux1->sig;
	}
	aux=aux1->ant;
	aux->sig=aux1->sig;
	aux1->sig->ant=aux;
	return aux1->info;
	delete aux1;

}
template<class T>
bool listaDoble<T>::lista_vacia(){
	return(cab->sig==z);
}

template<class T>
T listaDoble<T>::revisar_pos(int pos){
    int i;
	nodo<T> *aux,*aux1=cab;
	aux=new nodo<T>;
	for(i=1;i<=pos&& aux1->sig!=NULL;i++){
		aux1=aux1->sig;
	}
	return aux1->info;
}

#endif
