#include <iostream>
#include "listaDoble.h"
#include <conio.h>
#include <stdio.h>

using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	listaDoble<int> L(0);
	cout<<L.lista_vacia()<<endl;
	L.insertar_pos(2,1);
	L.insertar_pos(3,2);
	L.insertar_pos(4,3);
	L.insertar_pos(5,4);
	cout<<"Se eliminara: ";
	cout<<L.revisar_pos(2)<<endl;
	L.eliminar_pos(2);
	for(int i=1;i<=3;i++){
        cout<<L.revisar_pos(i)<<endl;
	}
	cout<<L.lista_vacia()<<endl;
	getch();
}
