#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <conio.h>
#include "listaDobleEnlazada.h"

using namespace std;

int main(int argc, char *argv[]){

    listaDobleEnlazada<int> L(0);
	cout<<L.lista_vacia()<<endl;
	L.insertar_pos(2,1);
	L.insertar_pos(3,2);
	L.insertar_pos(4,3);
	L.insertar_pos(5,4);
	cout<<"Se eliminara: ";
	cout<<L.revisar_pos(2)<<endl;
	L.eliminar_pos(2);
	for(int i=1;i<=4;i++){
        cout<<L.revisar_pos(i)<<endl;
	}
	cout<<L.lista_vacia()<<endl;
	cout<<L.revisar_ant(2)<<endl;
	cout<<L.revisar_sig(2);
	getch();
}
