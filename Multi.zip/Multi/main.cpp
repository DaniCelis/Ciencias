#include <iostream>
#include <string>
#include "multi.h"
#include<conio.h>

using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
    int opcionmenu=0;
    nombre<string> nom;
	carrera<int> Sis;
    carrera<int> Ele;
    carrera<int> Cat;
    carrera<int> Ind;
	
	hobbie<int> Dan;
	hobbie<int> Nat;
	hobbie<int> Bei;
	hobbie<int> Bas;
	
	edad<int> Edad;
	int ingid=0;
	string nombre="";
	int ingedad = 0;
	int opcioncarrera;
	int opcionHob;
	int op,op1,op2,n;
	do{

		cout<<"Menu: \n1. Ingrese Datos \n2. Consulte Datos\n3. Eliminar Datos\n4. Terminar"<<endl;
		cin>>opcionmenu;
		if(opcionmenu>4){
			cout<<"Numero Invalido"<<endl;
		}else{
			switch(opcionmenu){
				case 1:

					cout<<"el ID es"<<endl;
					ingid++;
					cout<<ingid<<endl;
					cout<<"Ingresa Nombre"<<endl;
					cin>>nombre;
					nom.insertar(nombre,ingid);
					do{
                        cout<<"Ingrese Carrera: \n1.Sistemas \n2.Electrica\n3.Catastral \n4.Industrial"<<endl;
						cin>>opcioncarrera;
						switch(opcioncarrera){
							case 1:
								Sis.insertarCarrera(ingid);
								break;
							case 2:
								Ele.insertarCarrera(ingid);
								break;
							case 3:
						    	Cat.insertarCarrera(ingid);
						    	break;
							case 4:
								Ind.insertarCarrera(ingid);
								break;
							default:
								cout<<"Dato incorrecto"<<endl;
								break;
						}
					}while(opcioncarrera>4);
					do{
                    	cout<<"Ingrese Hobbie: \n1.Danza \n2.Natacion\n3.Beisbol \n4.Basquet"<<endl;
						cin>>opcionHob;
						switch(opcionHob){
							case 1:
								Dan.insertarHobbie(ingid);
								break;
							case 2:
								Nat.insertarHobbie(ingid);
								break;
							case 3:
						    	Bei.insertarHobbie(ingid);
						    	break;
							case 4:
								Bas.insertarHobbie(ingid);
								break;
							default:
								cout<<"Dato incorrecto"<<endl;
								break;
						}
					}while(opcionHob>4);
					
					cout<<"Ingrese Edad"<<endl;
					cin>>ingedad;
					Edad.insertarEdad(ingid);
					break;

				case 2 :
					cout<<"Consulte Datos"<<endl;
					//Aqui falta hacer la estructura de la consulta, pero ya estan bien
					do{
                        cout<<"Seleccione la lista que desea ver :\n1.Nombre \n2.Carrera \n3.Hobbie\n4.Edad \n"<<endl;
						cin>>op;
						switch(op){
							case 1:
                                cout<<"El primero en nombre es:"<<endl;
						        cout<<nom.retornar(1)<<endl;
								break;
							case 2:
                                do{
                        			cout<<"consulte Carrera: \n1.Sistemas \n2.Electrica\n3.Catastral \n4.Industrial"<<endl;
									cin>>op1;
									switch(op1){
										case 1:
           									cout<<"El primero de esta carrera es:"<<endl;
											cout<<nom.retornarId(Sis.retornarCarrera(1))<<endl;
										
											break;
										case 2:
                                            cout<<"El primero de esta carrera es:"<<endl;
											cout<<nom.retornarId(Ele.retornarCarrera(1))<<endl;
           									
											break;
										case 3:
                                            cout<<"El primero de esta carrera es:"<<endl;
						    				cout<<nom.retornarId(Cat.retornarCarrera(1))<<endl;
						    				
						    				break;
										case 4:
                                        	cout<<"El primero de esta carrera es:"<<endl;
											cout<<nom.retornarId(Ind.retornarCarrera(1))<<endl;
											break;
										default:
											cout<<"Dato incorrecto"<<endl;
											break;
									}
								}while(op1>4);
								break;
							case 3:
                                do{
                        			cout<<"consulte Hobbie: \n1.Danza \n2.Natacion\n3.Beisbol \n4.Basquet"<<endl;
									cin>>op2;
									switch(op2){
										case 1:
											cout<<"El primero de este hobbie es:"<<endl;
											cout<<nom.retornarId(Dan.retornarHobbie(1))<<endl;

											break;
										case 2:
                                            cout<<"El primero de este hobbie es:"<<endl;
											cout<<nom.retornarId(Nat.retornarHobbie(1))<<endl;
											
											break;
										case 3:
                                            cout<<"El primero de este hobbie es:"<<endl;
						    				cout<<nom.retornarId(Bei.retornarHobbie(1))<<endl;
						    				
						    				break;
										case 4:
                                         cout<<"El primero de este hobbie es:"<<endl;
											cout<<nom.retornarId(Bas.retornarHobbie(1))<<endl;
											break;
										default:
											cout<<"Dato incorrecto"<<endl;
											break;
									}
								}while(op2>4);
								break;
							case 4:
						        cout<<"El primero en edad es:"<<endl;
						        cout<<nom.retornarId(Edad.retornarEdad(1))<<endl;
						    	break;
							default:
								cout<<"Dato incorrecto"<<endl;
								break;
						}
					}while(op>4);
					break;
				case 3:
					cout<<"Eliminar Datos"<<endl;
					cout<<"Ingresa el Id que debeas borrar";
					cin>>n;
					nom.eliminar(n);
					break;
			}
		}

	}while(opcionmenu!=4);
	
	getch();
	
}
