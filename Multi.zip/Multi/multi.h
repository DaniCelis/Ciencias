#ifndef MULTI_H
#define MULTI_H

#include <iostream>
#include <stdio.h>
#include <string>
#include <cstring>
using namespace std;

template <class T>
struct nodoNombre{
	int id;
	T nombre;
	nodoNombre<T> *sig,*ant;
};

template<class T>
struct nodoCarrera{
	T carrera;
	nodoCarrera<T> *sig;
};

template<class T>
struct nodoHobbie{
	T hobbie;
	nodoHobbie<T> *sig;
};
template<class T>
struct nodoEdad{
	T edad;
	nodoEdad<T> *sig;
};

template<class T>
class nombre{
	nodoNombre<T> *cabNom;
	public:
	nombre(){
        cabNom=new nodoNombre<T>;
        cabNom->nombre="";
        cabNom->id=0;
        cabNom->sig=0;
		cabNom->ant=0;
	}
	
	void insertar(T nomb,int id);
	T retornar(int pos);
	T retornarId(int id);
	void eliminar(int id);
};
template <class T>
class carrera{
	nodoCarrera<T> *cabCarr;
	
	public:

	carrera(){
        cabCarr=new nodoCarrera<T>;
   		cabCarr->carrera=0;
   		cabCarr->sig=0;
	}
	void insertarCarrera(T dato);
	T retornarCarrera(int pos);
	void eliminarCarrera(int id);
};


template <class T>
class hobbie{
	nodoHobbie<T> *cabHob;

	public:
		hobbie(){
			cabHob = new nodoHobbie<T>;
   			cabHob->hobbie=0;
			cabHob->sig=0;
		}

	void insertarHobbie(T dato);
	T retornarHobbie(int pos);
	void eliminarHobbie(int id);
};

template <class T>
class edad{
	nodoEdad<T> *cabEd;

	public:
		edad(){
   			cabEd = new nodoEdad<T>;
   			cabEd->edad =0;
			cabEd->sig=0;
		}

	void insertarEdad(T dato);
	T retornarEdad(int pos);
	void eliminarEdad(int id);
};

//FUNCIONES DE NOMBRE
template<class T>
void nombre<T>::insertar(T dato,int id){
	nodoNombre<T> *aux,*auxT,*aux1=cabNom;
	aux=new nodoNombre<T>;
	aux->id=id;
	aux->nombre=dato;
	aux->sig=0;
	while(aux1->sig != 0 && aux1->nombre.compare(aux->nombre)<0){
		aux1=aux1->sig;
	}
	auxT=aux1;
	if(aux1->nombre.compare(aux->nombre)>0){
			auxT=aux1;
            aux1=aux;
			aux=auxT;
			aux1->ant=aux->ant;
			aux->ant->sig=aux1;
	}
	aux1->sig=aux;
	aux->ant=aux1;
}

template<class T>
T nombre<T>::retornar(int pos){
    int i;
	nodoNombre<T> *aux,*aux1=cabNom;
	aux=new nodoNombre<T>;
	for(i=1;i<=pos&& aux1->sig!=NULL;i++){
		aux1=aux1->sig;
	}
	return aux1->nombre;
}
template<class T>
T nombre<T>::retornarId(int id){
	int i;
	nodoNombre<T> *aux,*aux1=cabNom;
    for(i=1;aux1->id!=id;i++){
		aux1=aux1->sig;
	}
	return aux1->nombre;
}
template<class T>
void nombre<T>::eliminar(int id){
	int i;
	nodoNombre<T> *aux,*aux1=cabNom;
    for(i=1;aux1->id!=id;i++){
		aux1=aux1->sig;
	}
	aux=aux1;
	aux=aux1->sig;
	aux1->ant->sig=aux;
	aux->ant=aux1->ant;
	delete aux1;
}
//FUNCIONES DE CARRERA

template <class T>
void carrera<T>::insertarCarrera(T dato){
	nodoCarrera<T> *aux, *aux1=cabCarr;
	aux = new nodoCarrera<T>;
	aux->carrera = dato;
	while(aux1->sig != 0){
		aux1 = aux1->sig;
	}
	aux1->sig = aux;
	aux->sig=0;
}

template<class T>
T carrera<T>::retornarCarrera(int pos){
    int i;
	nodoCarrera<T> *aux,*aux1=cabCarr;
	aux=new nodoCarrera<T>;
	for(i=1;i<=pos&& aux1->sig!=0;i++){
		aux1=aux1->sig;
	}
	return aux1->carrera;
}


template<class T>
void carrera<T>::eliminarCarrera(int id){
	int i;
	nodoCarrera<T> *aux,*aux1=cabCarr;
    for(i=1;aux1->id!=id;i++){
		aux1=aux1->sig;
	}
	delete aux1;
}

//FUNCIONES DE HOBBIE

template <class T>
void hobbie<T>::insertarHobbie(T dato){
	nodoHobbie<T> *aux, *aux1=cabHob;
	aux = new nodoHobbie<T>;
	aux->hobbie = dato;
	aux->sig = 0;

	aux->sig = aux1->sig;
	aux1->sig = aux;
}

template<class T>
T hobbie<T>::retornarHobbie(int pos){
    int i;
	nodoHobbie<T> *aux,*aux1=cabHob;
	aux=new nodoHobbie<T>;
	for(i=1;i<=pos&& aux1->sig!=0;i++){
		aux1=aux1->sig;
	}
	return aux1->hobbie;
}
template<class T>
void hobbie<T>::eliminarHobbie(int id){
	int i;
	nodoHobbie<T> *aux,*aux1=cabHob;
    for(i=1;aux1->id!=id;i++){
		aux1=aux1->sig;
	}
	delete aux1;
}

//FUNCIONES DE EDAD

template <class T>
void edad<T>::insertarEdad(T dato){
	nodoEdad<T> *aux, *aux1=cabEd;
	aux = new nodoEdad<T>;
	aux->edad = dato;
	aux->sig = 0;

	while(aux1->edad > aux->edad && aux1->sig->edad > aux->edad){
		aux1 = aux1->sig;
	}

 aux->sig = aux1->sig;
	aux1->sig = aux;
}

template<class T>
T edad<T>::retornarEdad(int pos){
    int i;
	nodoEdad<T> *aux,*aux1=cabEd;
	aux=new nodoEdad<T>;
	for(i=1;i<=pos&& aux1->sig!=0;i++){
		aux1=aux1->sig;
	}
	return aux1->edad;
}
template<class T>
void edad<T>::eliminarEdad(int id){
	int i;
	nodoEdad<T> *aux,*aux1=cabEd;
    for(i=1;aux1->id!=id;i++){
		aux1=aux1->sig;
	}
	delete aux1;
}




/*
template<class T>
void nombre<T>::insertar(T nomb){
	int i;
	nombre<T> *aux,*aux1;
	aux= new nombre<T>;
	aux->nom=nomb;
	while(palabraOrden(aux1->nom, aux->nom) && aux1->sig!=NULL){
		cout<<"mas mayor";
	}

	aux->sig=aux1->sig;
	aux1->sig->ant=aux;

}
template<class T>
bool nombre<T>::palabraOrden(string palabra1, string palabra2){

	char *nom1 = new char[palabra1.length()+1];
	strcpy(nom1, palabra1.c_str());

//	if(strcmp(nom1,nom2)>0){
	//	return false;
	//}else{
	//	return true;
	//}
}

*/
#endif
