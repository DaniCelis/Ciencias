#include <iostream>
#include<conio.h>
using namespace std;

int intercambio(int a[],int n,int i){
	int aux;
	aux=a[n];
	a[n]=a[i];
	a[i]=aux;
}
int burbuja (int a[], int N){
	int i,j;
  	for (i=N; i>=1; i--){
    	for(j=2; j<=i; j++)
           if(a[j-1]> a[j])
		   intercambio(a,j-1,j);		//comparaci�n e intercambio
	}
    for(i=0;i<N;i++){
		cout<<a[i];
	}
}


int main(){
	int a[]={1,3,4,2,5};
	burbuja(a,5);
	getch();

}
