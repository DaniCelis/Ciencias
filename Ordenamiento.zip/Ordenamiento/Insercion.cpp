#include <iostream>
#include<conio.h>
using namespace std;

int Insercion (int a[], int N){
	int i,j;
	int v;
	for (i=1; i<=N; i++){
		j=i;
		v=a[j];
        while(a[j-1]>v && j>1){      //Comparacion
			a[j]=a[j-1];			//1/2 intercambio
            j--;
        }
        a[j]= v;				//1/2 intercambio
	}
	
	for(i=0;i<N;i++){
		cout<<a[i];
	}
}

int main(){
	int a[]={5,3,2,1,4};
	Insercion(a,5);
	getch();

}
