#include <iostream>
#include<conio.h>
using namespace std;


int intercambio(int a[],int n,int i){
	int aux;
	aux=a[n];
	a[n]=a[i];
	a[i]=aux;
}

int Seleccion (int a[], int N){
	int i,j,min;
    for (i=0;i<N; i++){
		min = i;
		for (j=i+1;j<=N; j++)
	 		if(a[j]<a[min]) min = j;  //comparacion
			intercambio(a, min, i);  	//intercambio

 	}
 	for(i=0;i<N;i++){
		cout<<a[i];
	}
	
}

int main(){
	int a[]={5,3,2,1,4};
	Seleccion(a,5);
	getch();
}
