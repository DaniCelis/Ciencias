#include <iostream>
#include<conio.h>
#include <time.h>
#include <sys/time.h>
#include <windows.h>
#include <ctime>
#include <stdio.h>


using namespace std;

double performancecounter_diff(LARGE_INTEGER *a, LARGE_INTEGER *b){
  LARGE_INTEGER freq;
  QueryPerformanceFrequency(&freq);
  return (double)(a->QuadPart - b->QuadPart) / (double)freq.QuadPart;
}

int intercambio(int a[],int n,int i){
	int aux;
	aux=a[n];
	a[n]=a[i];
	a[i]=aux;
}
int burbuja (int a[], int N){
	int i,j;
  	for (i=N; i>=1; i--){
    	for(j=1; j<i; j++)
           if(a[j-1]> a[j])
		   intercambio(a,j-1,j);		//comparaci�n e intercambio
	}
}


int main(){
    int n;
	int aux;
	srand(time(NULL));
    LARGE_INTEGER t_inic, t_fina;
  	double sec;
  	srand(time(NULL));
  	cin>>n;
  	int a[n];
  	aux=n;
  	for(int i=0;i<n;i++){
		a[i]=aux;
		aux--;
	}
	
	QueryPerformanceCounter(&t_inic);
	burbuja(a,n);
	QueryPerformanceCounter(&t_fina);
	sec = performancecounter_diff(&t_fina, &t_inic);
	cout<<endl;
	printf("%.16g milisegundos\n", sec * 1000.0);
	getch();

}
