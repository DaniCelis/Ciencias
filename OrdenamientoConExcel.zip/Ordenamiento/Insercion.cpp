#include <iostream>
#include<conio.h>
#include <time.h>
#include <sys/time.h>
#include <windows.h>
#include <ctime>
#include <stdio.h>

using namespace std;

double performancecounter_diff(LARGE_INTEGER *a, LARGE_INTEGER *b){
  LARGE_INTEGER freq;
  QueryPerformanceFrequency(&freq);
  return (double)(a->QuadPart - b->QuadPart) / (double)freq.QuadPart;
}

int Insercion (int a[], int N){
	int i,j;
	int v;
	
	for (i=1; i<N; i++){
		j=i-1;
		v=a[j];
        while(a[j-1]>v && j>0){
						            //Comparacion
			a[j]=a[j-1];			//1/2 intercambio
            j--;
        }
        a[j]= v;				    //1/2 intercambio
	}
	
	
}

int main(){
    int n;
	int aux;
	srand(time(NULL));
    LARGE_INTEGER t_inic, t_fina;
  	double sec;
  	srand(time(NULL));
  	cin>>n;
  	int a[n];
  	aux=n;
  	for(int i=0;i<n;i++){
		a[i]=aux;
		aux--;
	}
	QueryPerformanceCounter(&t_inic);
	Insercion(a,n);
	QueryPerformanceCounter(&t_fina);
	sec = performancecounter_diff(&t_fina, &t_inic);
	cout<<endl;
	printf("%.16g milisegundos\n", sec * 1000.0);
	getch();

}
