#include <iostream>
#include<conio.h>
#include <time.h>
#include <sys/time.h>
#include <windows.h>
#include <ctime>
#include <stdio.h>

using namespace std;

double performancecounter_diff(LARGE_INTEGER *a, LARGE_INTEGER *b){
  LARGE_INTEGER freq;
  QueryPerformanceFrequency(&freq);
  return (double)(a->QuadPart - b->QuadPart) / (double)freq.QuadPart;
}

int intercambio(int a[],int n,int i){
	int aux;
	aux=a[n];
	a[n]=a[i];
	a[i]=aux;
}

void ordenrapido(int a[], int izq, int der){
	int i, j; int v;
		if (der> izq){
			v= a[der]; i = izq -1; j= der;
       		for(;;){
				while (a[++i]<v);
              	while (a[--j] >v);
              	if(i>=j) break;
              	intercambio(a,i,j);
			}
			intercambio(a, i, der);
       		ordenrapido(a, izq, i-1);
       		ordenrapido(a, i+1,der);
     }
}

int main(){
    int n;
	int aux;
	srand(time(NULL));
    LARGE_INTEGER t_inic, t_fina;
  	double sec;
  	srand(time(NULL));
  	cin>>n;
  	int a[n];
  	for(int i=0;i<n;i++){
		aux=rand()%100;
		a[i]=aux;
	}
	cout<<endl;
	QueryPerformanceCounter(&t_inic);
	ordenrapido(a,0,n);
	QueryPerformanceCounter(&t_fina);
	sec = performancecounter_diff(&t_fina, &t_inic);
	cout<<endl;
	printf("%.16g milisegundos\n", sec * 1000.0);

	getch();
	
}
