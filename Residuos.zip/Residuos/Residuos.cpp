#include <iostream>
#include<conio.h>
#include <time.h>
#include <sys/time.h>
#include <windows.h>
#include <ctime>
#include <stdio.h>
using namespace std;

double performancecounter_diff(LARGE_INTEGER *a, LARGE_INTEGER *b){
  LARGE_INTEGER freq;
  QueryPerformanceFrequency(&freq);
  return (double)(a->QuadPart - b->QuadPart) / (double)freq.QuadPart;
}

unsigned bits(char x, int k, int j){
	return(x>>k)&~(~0<<j);
}

int intercambio(char a[],int n,int i){
	int aux;
	aux=a[n];
	a[n]=a[i];
	a[i]=aux;
}

void cambioresiduos(char a[], int izq, int der, int b){
	int i,j;
	if (der>izq && b>=0){
		i= izq; 
		j=der;
		while(j!=i){
			while(!bits(a[i],b,1) && i<j)
				i++;
            while(bits(a[j],b,1) && j>i)
            	j--;
            intercambio(a, i, j);
    	}
        if (!bits(a[i],b,1)) 
			j++;
        cambioresiduos(a, izq, j-1, b-1);
		cambioresiduos(a, j, der, b-1);
	}
}



int main(){
	
	
	int b=6;
	int n=1;
	srand(time(NULL));
	LARGE_INTEGER t_inic, t_fina;
	double sec;
	
	do{
		cin>>n;
		char a[n];
		for(int i=0;i<n;i++){
			a[i] = rand() % 26 + 65 ; 
		}
		/*
		for(int j=0;j<n;j++){
			cout<<a[j];
		}	
		*/
		cout<<endl;
		
		QueryPerformanceCounter(&t_inic);
		cambioresiduos(a,0,n-1,b);
		QueryPerformanceCounter(&t_fina);
		sec = performancecounter_diff(&t_fina, &t_inic);
		printf("%.16g\n", sec * 1000.0);
		cout<<endl;
		
	/*	for(int j=0;j<n;j++){
			cout<<a[j];
		}
 	*/
	}while(n!=0);
	getch();
}
