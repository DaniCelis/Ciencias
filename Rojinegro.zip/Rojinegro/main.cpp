#include <cstdlib>
#include <iostream>
#include<conio.h>
#include "rojinegro.h"

using namespace std;

int main(int argc, char *argv[]){
	Arbol arbol;
	arbol.insertarRJ(arbol,5);
	getch();
}
