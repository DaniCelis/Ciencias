#ifndef ROJINEGRO_H
#define ROJINEGRO_H
#include<iostream>

using namespace std;

struct nodo{
	int valor;
	char color;
    nodo *izq, *der,*padre;
};

class Arbol{
	public:
        nodo *raiz;
		Arbol(){
			raiz=NULL;
		}
		void insertarRJ(Arbol a,int valor);
		void rotar_i(Arbol a,nodo *x);
		void rotar_d(Arbol a,nodo *x);
		void eliminar(Arbol a,nodo *x);
		void inorden(nodo *p);
};
void Arbol::insertarRJ(Arbol a,int valor){
	nodo *aux,*y,*aux1=raiz;
	if(raiz==NULL){
		raiz->valor=valor;
		raiz->padre=raiz->der=raiz->izq=NULL;
		raiz->color='N';
	}else{
		aux=new nodo;
		aux->valor=valor;
		aux->padre=aux->der=aux->izq=NULL;
		aux->color='R';
		bool encontrado=false;
		while(encontrado!=true){
			if(aux->valor > aux1->valor){
				if(aux1->der==NULL){
					aux1->der=aux;
					aux->padre=aux1;
					encontrado=true;
				}else{
					aux1=aux1->der;
				}
			}else{
				if(aux1->izq==NULL){
					aux1->izq=aux;
					aux->padre=aux;
					encontrado=true;
				}else{
					aux1=aux1->izq;
				}
			}
		}
	}
	while(aux!=raiz && aux->padre->color=='R'){
		if(aux->padre==aux->padre->padre->izq){
			y=aux->padre->padre->der;
			if(y->color=='R'){
				aux->padre->color='N';
				y->color='N';
				aux->padre->padre->color='R';
				aux=aux->padre->padre;
			}else{
				if(aux=aux->padre->der){
					aux=aux->padre;
					rotar_i(a,aux);
				}
				aux->padre->color='N';
				aux->padre->padre->color='R';
				rotar_d(a,aux->padre->padre);
			}
		}else{
            y=aux->padre->padre->izq;
			if(y->color=='R'){
				aux->padre->color='N';
				y->color='N';
				aux->padre->padre->color='R';
				aux=aux->padre->padre;
			}else{
				if(aux=aux->padre->izq){
					aux=aux->padre;
					rotar_d(a,aux);
				}
				aux->padre->color='N';
				aux->padre->padre->color='R';
				rotar_i(a,aux->padre->padre);
			}
		}
	}
	raiz->color='N';
}

void Arbol::rotar_i(Arbol a,nodo *x){
	nodo *y;
	y=x->der;
	x->der=y->izq;
	if(y->izq!=NULL){
		x=y->izq->padre;
	}
	y->padre=x->padre;
	if(x->padre==NULL){
		raiz=y;
	}else{
		if(x==x->padre->izq){
			x->padre->izq=y;
		}else{
			x->padre->der=y;
		}
	}
	y->izq=x;
	x->padre=y;
}
void Arbol::rotar_d(Arbol a,nodo *x){
	nodo *y;
	y=x->izq;
	x->izq=y->der;
	if(y->der!=NULL){
		x=y->der->padre;
	}
	y->padre=x->padre;
	if(x->padre==NULL){
		raiz=y;
	}else{
		if(x==x->padre->der){
			x->padre->der=y;
		}else{
			x->padre->izq=y;
		}
	}
	y->der=x;
	x->padre=y;
}


#endif
