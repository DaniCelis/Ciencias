#include<iostream>
#include<conio.h>
#include <iostream>
#include<conio.h>
#include <time.h>
#include <sys/time.h>
#include <windows.h>
#include <ctime>
#include <stdio.h>

using namespace std;

/*void sumar(int a[n][n],int b[n][n],int c[n][n],int n){
	int i,j;

	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			c[i][j]=a[i][j]+b[i][j];
		}
	}
    cout<<"Matriz A+B"<<endl;
	for(int i=0;i<n;i++){
		for (int j=0;j<n;j++){
			cout<<c[i][j]<<" ";
		}
		cout<<endl;
	}
}
*/

double performancecounter_diff(LARGE_INTEGER *a, LARGE_INTEGER *b){
  LARGE_INTEGER freq;
  QueryPerformanceFrequency(&freq);
  return (double)(a->QuadPart - b->QuadPart) / (double)freq.QuadPart;
}

int main(){
	int n,aux;
	cin>>n;
	srand(time(NULL));
    LARGE_INTEGER t_inic, t_fina;
  	double sec;
  	srand(time(NULL));
	int a[n][n],b[n][n],c[n][n];
	aux=1;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			a[i][j]=aux;
			aux++;
		}
	}
 	aux=1;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			b[i][j]=aux;
			aux++;
		}
	}
	QueryPerformanceCounter(&t_inic);
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			c[i][j]=a[i][j]+b[i][j];
		}
	}
	QueryPerformanceCounter(&t_fina);
	sec = performancecounter_diff(&t_fina, &t_inic);
	cout<<endl;
	printf("%.16g milisegundos\n", sec * 1000.0);
 /* cout<<"Matriz A+B"<<endl;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			cout<<c[i][j]<<" ";
  		}
  		cout<<endl;
 	}
 */
	getch();
}

